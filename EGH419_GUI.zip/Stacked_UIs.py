from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtCore import Qt
#from time import sleep

import sys
from time import sleep

Selection = {
    #is chosen, servo pin, angle, time stays at angle
    "Cheddar": [0, 1, 90, 2],
    "Capsicum": [0, 1, 90, 2],
    "Olive": [0, 1, 90, 2],
    "Ham": [0, 1, 90, 2]
}
ingredients = ["Cheddar", "Capsicum","Olive","Ham"]

def printtest():
    print("Button Pressed")
    #sleep(3)
    showMain.OpenWindow0()

class Ui_Main(QtWidgets.QWidget):
    def setupUi(self, Main):
        Main.setObjectName("Main")
        Main.resize(800, 480)

        self.QtStack = QtWidgets.QStackedLayout()

        self.stack1 = QtWidgets.QMainWindow()
        self.stack2 = QtWidgets.QWidget()
        self.stack3 = QtWidgets.QWidget()
        self.stack4 = QtWidgets.QWidget()

        self.Window1UI()
        self.Window2UI()
        self.Window3UI()
        self.Window4UI()

        self.QtStack.addWidget(self.stack1)
        self.QtStack.addWidget(self.stack2)
        self.QtStack.addWidget(self.stack3)
        self.QtStack.addWidget(self.stack4)

    #-----------------------Main window
    def Window1UI(self):
        self.stack1.resize(800, 480)
        #self.stack1.setWindowFlags(Qt.CustomizeWindowHint)---------------------------Uncomment for final

        #PushButton1#
        self.stack1.setStyleSheet("QMainWindow {background-image: url(Main_Background.png)}") #; background-attachment: fixed
        self.MainLabel = QtWidgets.QLabel(self.stack1)
        self.MainLabel.setText("Please select ingrediants")
        self.MainLabel.setGeometry(QtCore.QRect(250, 240, 300, 100))
        #self.MainLabel.setStyleSheet("QLabel {background-image: url(Olive.png)}")

        app.setStyleSheet("QLabel{font-size: 18pt;}")


        self.PushButton1 = QtWidgets.QPushButton(self.stack1)
        self.PushButton1.setText("Meat")
        self.PushButton1.setGeometry(QtCore.QRect(50, 100, 100, 100))
        

        self.PushButton2 = QtWidgets.QPushButton(self.stack1)
        self.PushButton2.setText("Vegetables")
        self.PushButton2.setGeometry(QtCore.QRect(250, 100, 100, 100))

        self.PushButton3 = QtWidgets.QPushButton(self.stack1)
        self.PushButton3.setText("Cheese")
        self.PushButton3.setGeometry(QtCore.QRect(450, 100, 100, 100))

        self.PushButton4 = QtWidgets.QPushButton(self.stack1)
        self.PushButton4.setText("Premade\n Pizzas")
        self.PushButton4.setGeometry(QtCore.QRect(650, 100, 100, 100))

        self.PushButton5 = QtWidgets.QPushButton(self.stack1)
        self.PushButton5.setText("Confirm")
        self.PushButton5.setGeometry(QtCore.QRect(200, 350, 400, 100))
        
        

        
        #------------Confirmation Window
    def Window2UI(self):
        
        
        self.stack2.resize(800, 480)
        self.stack2.setWindowFlags(Qt.CustomizeWindowHint)
        self.FATPAC = QtWidgets.QLabel(self.stack2)
        self.FATPAC.setGeometry(QtCore.QRect(600, 280, 200, 200))
        pixmap = QtGui.QPixmap('FatPacLogo.png')
        smaller_pixmap = pixmap.scaled(200, 200, Qt.KeepAspectRatio, Qt.FastTransformation)
        self.FATPAC.setPixmap(smaller_pixmap)
        

        self.MainLabel4 = QtWidgets.QLabel(self.stack2)
        self.MainLabel4.setText("You have not selected any ingredients, \n Do you want to proceed?")
        self.MainLabel4.setGeometry(QtCore.QRect(300, 10, 300, 100))
        self.PushButton8 = QtWidgets.QPushButton(self.stack2)
        self.PushButton8.setText("Confirm")
        self.PushButton8.setGeometry(QtCore.QRect(200, 350, 400, 100))
        self.PushButton9 = QtWidgets.QPushButton(self.stack2)
        self.PushButton9.setText("Back")
        self.PushButton9.setGeometry(QtCore.QRect(200, 150, 400, 100))

    #---------------Loading window
    def Window3UI(self):
        self.stack3.resize(800, 480)
        self.stack3.setWindowFlags(Qt.CustomizeWindowHint)

        self.FATPAC = QtWidgets.QLabel(self.stack3)
        self.FATPAC.setGeometry(QtCore.QRect(200, 40, 400, 400))
        pixmap = QtGui.QPixmap('FatPacLogo.png')
        smaller_pixmap = pixmap.scaled(400, 400, Qt.KeepAspectRatio, Qt.FastTransformation)
        self.FATPAC.setPixmap(smaller_pixmap)

        self.MainLabel2 = QtWidgets.QLabel(self.stack3)
        self.MainLabel2.setText("Pizza is being topped")
        self.MainLabel2.setGeometry(QtCore.QRect(300, 10, 300, 100))
        self.PushButton6 = QtWidgets.QPushButton(self.stack3)
        self.PushButton6.setText("Continue")
        self.PushButton6.setGeometry(QtCore.QRect(250, 400, 300, 50))

    #--------------Finished window
    def Window4UI(self):
        self.stack4.resize(800, 480)
        self.stack4.setWindowFlags(Qt.CustomizeWindowHint)

        self.FATPAC = QtWidgets.QLabel(self.stack4)
        self.FATPAC.setGeometry(QtCore.QRect(200, 40, 400, 400))
        pixmap = QtGui.QPixmap('FatPacLogo.png')
        smaller_pixmap = pixmap.scaled(400, 400, Qt.KeepAspectRatio, Qt.FastTransformation)
        self.FATPAC.setPixmap(smaller_pixmap)

        self.MainLabel3 = QtWidgets.QLabel(self.stack4)
        self.MainLabel3.setText("Pizza is finished. Please remove your pizza from the robot.")
        self.MainLabel3.setGeometry(QtCore.QRect(100, 0, 600, 100))
        self.MainLabel7 = QtWidgets.QLabel(self.stack4)
        self.MainLabel7.setText("Thank you for your patranige, have a nice day")
        self.MainLabel7.setGeometry(QtCore.QRect(100, 40, 600, 100))
        self.PushButton7 = QtWidgets.QPushButton(self.stack4)
        self.PushButton7.setText("Continue")
        self.PushButton7.setGeometry(QtCore.QRect(250, 400, 300, 50))


class VeggieWindow(QtWidgets.QWidget):
    def setup_Veggies(self, PopOut):
        super().__init__()
        PopOut.resize(800, 480)
        PopOut.setWindowTitle("Veggies")
        PopOut.setWindowFlags(Qt.CustomizeWindowHint)

        self.Veggie_label = QtWidgets.QLabel(PopOut)
        self.Veggie_label.setText("Please select your Vegetables")
        self.Veggie_label.setGeometry(QtCore.QRect(250, 10, 300, 100))

        self.Capsicum = QtWidgets.QPushButton(PopOut)
        self.Capsicum.setText("Green Capsicum")
        self.Capsicum.setGeometry(QtCore.QRect(130, 100, 250, 100))
        self.Capsicum.setCheckable(True)
        self.Capsicum.setIcon(QtGui.QIcon('pngegg.png'))
        self.Capsicum.setIconSize(QtCore.QSize(100, 100))
        if Selection["Capsicum"][0] == 1 :
            self.Capsicum.setChecked(True)
        self.Capsicum.clicked.connect(self.Update_Selection_Capsicum)

        self.Olive = QtWidgets.QPushButton(PopOut)
        self.Olive.setText("Olives")
        self.Olive.setGeometry(QtCore.QRect(420, 100, 250, 100))
        self.Olive.setCheckable(True)
        self.Olive.setIcon(QtGui.QIcon('Olive.png'))
        self.Olive.setIconSize(QtCore.QSize(100, 100))
        if Selection["Olive"][0] == 1 :
            self.Olive.setChecked(True)
        self.Olive.clicked.connect(self.Update_Selection_Olive)

        self.Close = QtWidgets.QPushButton(PopOut)
        self.Close.setText("Close")
        self.Close.setGeometry(QtCore.QRect(275, 250, 150, 75))
        self.Close.clicked.connect(PopOut.hide)

    def Update_Selection_Capsicum(self):
        if(self.Capsicum.isChecked()):
            Selection["Capsicum"][0] = 1
        else:
            Selection["Capsicum"][0] = 0

    def Update_Selection_Olive(self):
        if(self.Olive.isChecked()):
            Selection["Olive"][0] = 1
        else:
            Selection["Olive"][0] = 0

        #---------------------------Old code for selection
        #layout = QtWidgets.QGridLayout()
        #layout.addWidget(QtWidgets.QLabel("Please select your vegatables"), 0, 0)
        #layout.addWidget(QtWidgets.QPushButton("Green Capsicum"), 1, 0)
        #layout.addWidget(QtWidgets.QPushButton("Olives"), 1, 1)
        #layout.addWidget(QtWidgets.QPushButton("Close", clicked = lambda: self.close_self(PopOut)), 2, 0)

        # Set the central widget of the Window.
        #PopOut.setLayout(layout)
    #def close_self(self, PopOut):
        #self.close()
        #PopOut.close()

class MeatWindow(QtWidgets.QWidget):
    def setup_Meat(self, PopOut):
        super().__init__()
        PopOut.resize(800, 480)
        PopOut.setWindowTitle("Meat")
        PopOut.setWindowFlags(Qt.CustomizeWindowHint)

        self.Meat_label = QtWidgets.QLabel(PopOut)
        self.Meat_label.setText("Please select your meat")
        self.Meat_label.setGeometry(QtCore.QRect(250, 10, 300, 100))

        self.Ham = QtWidgets.QPushButton(PopOut)
        self.Ham.setText("Ham")
        self.Ham.setGeometry(QtCore.QRect(130, 100, 250, 100))
        self.Ham.setCheckable(True)
        self.Ham.setIcon(QtGui.QIcon('Ham.png'))
        self.Ham.setIconSize(QtCore.QSize(100, 100))
        if Selection["Ham"][0] == 1 :
            self.Ham.setChecked(True)
        self.Ham.clicked.connect(self.Update_Selection_Ham)

        self.Close = QtWidgets.QPushButton(PopOut)
        self.Close.setText("Close")
        self.Close.setGeometry(QtCore.QRect(275, 250, 150, 75))
        self.Close.clicked.connect(PopOut.close)

    def Update_Selection_Ham(self):
        if(self.Ham.isChecked()):
            Selection["Ham"][0] = 1
        else:
            Selection["Ham"][0] = 0

class CheeseWindow(QtWidgets.QWidget):
    def setup_Cheese(self, PopOut):
        super().__init__()
        PopOut.resize(800, 480)
        PopOut.setWindowTitle("Cheese")
        PopOut.setWindowFlags(Qt.CustomizeWindowHint)

        self.Cheese_label = QtWidgets.QLabel(PopOut)
        self.Cheese_label.setText("Please select your cheese")
        self.Cheese_label.setGeometry(QtCore.QRect(250, 10, 300, 100))

        self.Cheddar = QtWidgets.QPushButton(PopOut)
        self.Cheddar.setText("Cheddar")
        self.Cheddar.setGeometry(QtCore.QRect(130, 100, 250, 100))
        self.Cheddar.setCheckable(True)
        self.Cheddar.setIcon(QtGui.QIcon('Cheddar.png'))
        self.Cheddar.setIconSize(QtCore.QSize(100, 100))
        if Selection["Cheddar"][0] == 1 :
            self.Cheddar.setChecked(True)
        self.Cheddar.clicked.connect(self.Update_Selection_Cheddar)

        self.Close = QtWidgets.QPushButton(PopOut)
        self.Close.setText("Close")
        self.Close.setGeometry(QtCore.QRect(275, 250, 150, 75))
        self.Close.clicked.connect(PopOut.close)

    def Update_Selection_Cheddar(self):
        if(self.Cheddar.isChecked()):
            Selection["Cheddar"][0] = 1
        else:
            Selection["Cheddar"][0] = 0

class PremadeWindow(QtWidgets.QWidget):
    def setup_Premade(self, PopOut):
        super().__init__()
        PopOut.resize(800, 480)
        PopOut.setWindowTitle("Pre-made")
        PopOut.setWindowFlags(Qt.CustomizeWindowHint)

        self.Pre_made_label = QtWidgets.QLabel(PopOut)
        self.Pre_made_label.setText("Please select your Pre-designed Pizza")
        self.Pre_made_label.setGeometry(QtCore.QRect(250, 10, 300, 100))

        self.Everything = QtWidgets.QPushButton(PopOut)
        self.Everything.setText("Everything")
        self.Everything.setGeometry(QtCore.QRect(63, 100, 150, 100))
        self.Everything.setCheckable(True)
        if (Selection["Capsicum"][0] == 1 and Selection ["Olive"][0]== 1 and Selection ["Ham"][0] == 1 and Selection ["Cheddar"][0] == 1):
            self.Everything.setChecked(True)
        self.Everything.clicked.connect(self.Update_Selection_Everything)

        self.Meatlovers = QtWidgets.QPushButton(PopOut)
        self.Meatlovers.setText("Meatlovers")
        self.Meatlovers.setGeometry(QtCore.QRect(275, 100, 150, 100))
        self.Meatlovers.setCheckable(True)
        if (Selection["Capsicum"][0] == 0 and Selection ["Olive"][0]== 0 and Selection ["Ham"][0] == 1 and Selection ["Cheddar"][0] == 1):
            self.Meatlovers.setChecked(True)
        self.Meatlovers.clicked.connect(self.Update_Selection_Meatlovers)

        self.Vegetarian = QtWidgets.QPushButton(PopOut)
        self.Vegetarian.setText("Vegetarian")
        self.Vegetarian.setGeometry(QtCore.QRect(487, 100, 150, 100))
        self.Vegetarian.setCheckable(True)
        if (Selection["Capsicum"][0] == 1 and Selection ["Olive"][0]== 1 and Selection ["Ham"][0] == 0 and Selection ["Cheddar"][0] == 1):
            self.Vegetarian.setChecked(True)
        self.Vegetarian.clicked.connect(self.Update_Selection_Vegetarian)

        self.Close = QtWidgets.QPushButton(PopOut)
        self.Close.setText("Close")
        self.Close.setGeometry(QtCore.QRect(275, 250, 150, 75))
        self.Close.clicked.connect(PopOut.close)
    
    def Update_Selection_Everything(self):
        if(self.Everything.isChecked()):
            Selection["Capsicum"][0] = 1
            Selection["Olive"][0] = 1
            Selection["Ham"][0] = 1
            Selection["Cheddar"][0] = 1
            self.Meatlovers.setChecked(False)
            self.Vegetarian.setChecked(False)
        
    def Update_Selection_Meatlovers(self):
        if(self.Meatlovers.isChecked()):
            Selection["Capsicum"][0] = 0
            Selection["Olive"][0] = 0
            Selection["Ham"][0] = 1
            Selection["Cheddar"][0] = 1
            self.Vegetarian.setChecked(False)
            self.Everything.setChecked(False)
    
    def Update_Selection_Vegetarian(self):
        if(self.Vegetarian.isChecked()):
            Selection["Capsicum"][0] = 1
            Selection["Olive"][0] = 1
            Selection["Ham"][0] = 0
            Selection["Cheddar"][0] = 1
            self.Meatlovers.setChecked(False)
            self.Everything.setChecked(False)

class Main(QMainWindow, Ui_Main):
    def __init__(self, parent=None):
        super(Main, self).__init__(parent)
        self.setupUi(self)

        self.PushButton1.clicked.connect(self.openMWindow)
        self.PushButton2.clicked.connect(self.openVWindow)
        self.PushButton3.clicked.connect(self.openCWindow)
        self.PushButton4.clicked.connect(self.openPWindow)
        self.PushButton5.clicked.connect(self.OpenWindow1)
        self.PushButton6.clicked.connect(self.OpenWindow3)
        #self.PushButton7.clicked.connect(self.OpenWindow0)
        self.PushButton8.clicked.connect(self.OpenWindow2)
        self.PushButton9.clicked.connect(self.OpenWindow0)
        self.PushButton7.clicked.connect(printtest)

    def OpenWindow1(self):
        name = ""
        if (Selection["Capsicum"][0] == 0 and Selection ["Olive"][0]== 0 and Selection ["Ham"][0] == 0 and Selection ["Cheddar"][0] == 0):
            name = "No ingrediants"
        elif (Selection["Capsicum"][0] == 1 and Selection ["Olive"][0]== 1 and Selection ["Ham"][0] == 1 and Selection ["Cheddar"][0] == 1):
            name = "Everything Pizza"
        elif (Selection["Capsicum"][0] == 0 and Selection ["Olive"][0]== 0 and Selection ["Ham"][0] == 1 and Selection ["Cheddar"][0] == 1):
            name = "Meatlovers Pizza"
        elif (Selection["Capsicum"][0] == 1 and Selection ["Olive"][0]== 1 and Selection ["Ham"][0] == 0 and Selection ["Cheddar"][0] == 1):
            name = "Vegetarian Pizza"
        else:
            if Selection["Capsicum"][0] == 1:
                name = name + "Capsicum "
            if Selection["Olive"][0] == 1:
                name = name + "Olives "
            if Selection["Ham"][0] == 1:
                name = name + "Ham "
            if Selection["Cheddar"][0] == 1:
                name = name + "Cheddar "
        self.MainLabel4.setText("You have selected \n {} \n Do you wish to proceed".format(name))

        self.QtStack.setCurrentIndex(1)
        

    def OpenWindow2(self):
        self.QtStack.setCurrentIndex(2)

    def OpenWindow3(self):
        self.QtStack.setCurrentIndex(3)

    def OpenWindow0(self):
        self.QtStack.setCurrentIndex(0)

    def openVWindow(self):
        self.window = QtWidgets.QWidget()
        #self.window.setModal(True)
        self.ui = VeggieWindow()
        self.ui.setup_Veggies(self.window)
        self.window.show()

    def openMWindow(self):
        self.window = QtWidgets.QWidget()
        self.ui = MeatWindow()
        self.ui.setup_Meat(self.window)
        self.window.show()

    def openCWindow(self):
        self.window = QtWidgets.QWidget()
        self.ui = CheeseWindow()
        self.ui.setup_Cheese(self.window)
        self.window.show()

    def openPWindow(self):
        self.window = QtWidgets.QWidget()
        self.ui = PremadeWindow()
        self.ui.setup_Premade(self.window)
        self.window.show()
"""
def Topping():
    for i in ingredients:
        if(Selection(i)[0] == 1):
            showMain.setwindowFL()
            servo(Selection(i)[1], Selection(i)[2], Selection(i)[3])
            sifter()
            if (QC() < Threshold):
                servo(Selection[i][1], Selection(i)[2], Selection(i)[3])
                sifter()
                if(QC() < Threshold):
                    showMain.setwindowQCE()
    showMain.setwindowFL()
    daveFinalFunction()
"""
    

if __name__ == '__main__':
    app = QApplication(sys.argv)
    showMain = Main()
    sys.exit(app.exec_())